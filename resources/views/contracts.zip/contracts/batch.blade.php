<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Batch</title>
    <link rel="stylesheet" href="/public/bootstrap/css/bootstrap.css">
<style>


    body,
    .content {
        width: 75%;
        display: block;
        margin: auto;
        font-size:18px;
    }
    .content
    {
        border:1px solid #000;
        padding:2%;
    }
    .content:before
    {
        background-image:url("/images/backgroundimg.jpeg");
        background-size:contain;
        content: "";
        display: block;
        position: absolute;
        top: 50%;
        left: 40%;
        width:20%;
        height: 100%;
        z-index: -2;
        opacity: 0.2;
        background-repeat: no-repeat;
    }
    .top-header {
        text-align: center;
    }

    .text-left {
        display: inline-block;
    }

    .bold {
        font-weight: bold;
    }
    .half-sec
    {
        width:50%;
    }
    ul{
        list-style:none;
    }
    li{
        padding-bottom:2%;
    }
    html,
    body {
        font-family: DejaVu Sans, sans-serif ;
        direction: rtl;
        text-align: right;
    }
</style>
</head>
<body>
<div class="content">
    <div class="top-header">
        <div class="row">
            <div class="col"  style="font-weight:bold;font-size:19px"> مرسى قرية القطان</div>
            <div class="col">
                <img src="images/topimg.jpeg" style="width: 150px;height: 100px"/>
            </div>
            <div class="col">
                <p class="bold"><span style="font-size:19px;">AlqattanMarrine</p>
            </div>
        </div>
    </div>
    <!-- start Heading -->
    <h3 class="text-center"  style="font-weight:bold">سند القبض</h3>
    <!-- top data -->
    <ul>
        <li>التاريخ {{\Carbon\Carbon::today()->toDateString()}}</li>
        <li>استلمنا من السيد / {{$contract[0]->name}} </li>
        <li>مبلغ وقدر/{{$contract[0]->amount}} ريال فقط</li>
        <li>وذألك مقابل دفعه من الايجار الواسطة البحرية و المسماة  ({{$contract[0]->wastaname}})رقم({{$contract[0]->codewasta}}) </li>
        <li>الدفعه من ({{$contract[0]->from}}) الى ( {{$contract[0]->to}})</li>
        <li>التوقيع /</li>
        <img src="images/assign.jpeg" style="width:100px;height:100px;margin-top:4%;"/>
        <img src="images/khetm.jpeg" style="width:100px;height:100px;margin-top:4%;"/>
        <p class="col-sm-12" style="margin-top:20%">اسم المستخدم : {{$contract[0]->owner}}</p>
        <hr style="background-color:#000;height:2px;margin-top:20%"/>
        <p class="bold text-center" style="font-size:12px">المملكة العربية السعوديه - الشعيبة - شركة المراسم الملكية - مرسى قريه القطان - جوال 0597630207  alqattan.marrine@gmail.com</span>
        <hr style="background-color:#000;height:2px;"/>
        </p>
    </ul>
</div>
</body>

</html>
